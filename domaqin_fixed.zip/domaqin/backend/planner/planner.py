from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Iterable
from .geometry import GRID_W, GRID_H, to_grid, to_norm, route_length
from .algorithms.base import GridPoint, PlanResult
from .algorithms.astar import astar
from .algorithms.dijkstra import dijkstra
from .algorithms.rrt_star import rrt_star

@dataclass
class PlannerInput:
    start: dict[str, float]
    destination: dict[str, float]
    obstacles: list[dict[str, float]]
    restricted: list[dict[str, float]]
    safety_margin: float
    battery_reserve_pct: float
    algorithm: str
    payload_weight_kg: float
    speed_mps: float

class GridPlanner:
    def __init__(self, data: PlannerInput):
        self.data = data
        self.start = to_grid(data.start)
        self.goal = to_grid(data.destination)
        self.blocked: set[GridPoint] = set()
        self.restricted: set[GridPoint] = set()
        self._build_layers()

    def _build_layers(self) -> None:
        # The operating area is a normalized simulation canvas. Safety margin maps to a conservative grid radius.
        radius_cells = max(1, int(round(self.data.safety_margin / 40)))
        for o in self.data.obstacles:
            cx, cy = to_grid(o)
            r = max(radius_cells, int(round(o.get("radius", 0.045) * GRID_W * 0.9)))
            for x in range(cx - r, cx + r + 1):
                for y in range(cy - r, cy + r + 1):
                    if 0 <= x < GRID_W and 0 <= y < GRID_H and math.dist((x, y), (cx, cy)) <= r:
                        self.blocked.add((x, y))
        for o in self.data.restricted:
            cx, cy = to_grid(o)
            r = max(1, int(round(o.get("radius", 0.06) * GRID_W)))
            for x in range(cx - r, cx + r + 1):
                for y in range(cy - r, cy + r + 1):
                    if 0 <= x < GRID_W and 0 <= y < GRID_H and math.dist((x, y), (cx, cy)) <= r:
                        self.restricted.add((x, y))

    def valid(self, p: GridPoint) -> bool:
        return 0 <= p[0] < GRID_W and 0 <= p[1] < GRID_H and p not in self.blocked and p not in self.restricted

    def neighbors(self, p: GridPoint) -> Iterable[GridPoint]:
        for dx, dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,1),(1,-1),(-1,-1)):
            q = (p[0] + dx, p[1] + dy)
            if self.valid(q):
                yield q

    def cost(self, a: GridPoint, b: GridPoint) -> float:
        distance = math.dist(a, b)
        obstacle_proximity = self._proximity_penalty(b)
        battery_factor = max(0.0, (35 - self.data.battery_reserve_pct) / 35)
        payload_factor = 1 + (self.data.payload_weight_kg * 0.08)
        return distance * payload_factor + obstacle_proximity * 1.8 + battery_factor * 0.06

    def _proximity_penalty(self, p: GridPoint) -> float:
        min_d = 99.0
        for b in self.blocked:
            min_d = min(min_d, math.dist(p, b))
            if min_d <= 1:
                return 3.0
        return 0.8 if min_d <= 3 else 0.0

    def plan(self) -> PlanResult:
        if not self.valid(self.start):
            raise ValueError("The mission start point is inside an obstacle or restricted zone.")
        if not self.valid(self.goal):
            raise ValueError("The destination is inside an obstacle or restricted zone.")
        algo = self.data.algorithm
        if algo == "A*":
            result = astar(self.start, self.goal, self.neighbors, self.cost)
        elif algo == "Dijkstra":
            result = dijkstra(self.start, self.goal, self.neighbors, self.cost)
        elif algo == "RRT*":
            result = rrt_star(self.start, self.goal, self.neighbors, self.cost, GRID_W, GRID_H, self.valid)
        else:
            # Hybrid: use A* for guaranteed grid connectivity, then shortcut with geometry-aware smoothing.
            result = astar(self.start, self.goal, self.neighbors, self.cost)
            if result.path:
                result = PlanResult(self._smooth(result.path), result.nodes_evaluated, max(result.candidate_paths, 3), result.obstacles_avoided)
        if not result.path:
            raise ValueError("No safe route could be generated with the current constraints.")
        result.obstacles_avoided = sum(1 for p in result.path if p in self.blocked or p in self.restricted)
        return result

    def _smooth(self, path: list[GridPoint]) -> list[GridPoint]:
        if len(path) <= 2:
            return path
        out = [path[0]]
        last_dir: tuple[int, int] | None = None
        for i in range(1, len(path)):
            prev = path[i - 1]
            curr = path[i]
            direction = (curr[0] - prev[0], curr[1] - prev[1])
            if direction != last_dir:
                out.append(prev)
                last_dir = direction
        out.append(path[-1])
        # remove duplicates and guarantee endpoints
        clean: list[GridPoint] = []
        for p in out:
            if not clean or p != clean[-1]: clean.append(p)
        return clean

    def normalize_path(self, path: list[GridPoint]) -> list[dict[str, float]]:
        return [to_norm(p) for p in path]
