from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

DB_PATH = Path(__file__).resolve().parents[2] / "domaqin.sqlite3"

SCHEMA = """
CREATE TABLE IF NOT EXISTS missions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  mission_type TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  start_json TEXT NOT NULL,
  destination_json TEXT NOT NULL,
  algorithm TEXT NOT NULL,
  constraints_json TEXT NOT NULL,
  drone_json TEXT NOT NULL,
  distance_km REAL NOT NULL DEFAULT 0,
  flight_time_min REAL NOT NULL DEFAULT 0,
  battery_usage_pct REAL NOT NULL DEFAULT 0,
  waypoints INTEGER NOT NULL DEFAULT 0,
  replans INTEGER NOT NULL DEFAULT 0,
  obstacles_avoided INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS mission_routes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mission_id INTEGER NOT NULL,
  route_json TEXT NOT NULL,
  is_current INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  FOREIGN KEY(mission_id) REFERENCES missions(id)
);
CREATE TABLE IF NOT EXISTS waypoints (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mission_id INTEGER NOT NULL,
  point_json TEXT NOT NULL,
  sequence_no INTEGER NOT NULL,
  FOREIGN KEY(mission_id) REFERENCES missions(id)
);
CREATE TABLE IF NOT EXISTS obstacles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mission_id INTEGER NOT NULL,
  x REAL NOT NULL,
  y REAL NOT NULL,
  radius REAL NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  FOREIGN KEY(mission_id) REFERENCES missions(id)
);
CREATE TABLE IF NOT EXISTS simulation_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mission_id INTEGER NOT NULL,
  progress_pct REAL NOT NULL DEFAULT 0,
  battery_pct REAL NOT NULL,
  distance_km REAL NOT NULL DEFAULT 0,
  simulated_seconds REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'READY',
  FOREIGN KEY(mission_id) REFERENCES missions(id)
);
CREATE TABLE IF NOT EXISTS telemetry (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mission_id INTEGER NOT NULL,
  battery_pct REAL NOT NULL,
  speed_mps REAL NOT NULL,
  altitude_m REAL NOT NULL,
  distance_km REAL NOT NULL,
  progress_pct REAL NOT NULL,
  eta_sec INTEGER NOT NULL,
  heading TEXT NOT NULL,
  current_waypoint INTEGER NOT NULL,
  status TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(mission_id) REFERENCES missions(id)
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mission_id INTEGER NOT NULL,
  event_type TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(mission_id) REFERENCES missions(id)
);
"""

def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)

def insert_mission(payload: dict[str, Any], created_at: str) -> int:
    with connect() as conn:
        cur = conn.execute(
            """INSERT INTO missions
            (name, mission_type, description, status, created_at, start_json, destination_json,
             algorithm, constraints_json, drone_json, distance_km, flight_time_min, battery_usage_pct,
             waypoints, replans, obstacles_avoided)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 0)""",
            (payload["name"], payload["mission_type"], payload["description"], "DRAFT", created_at,
             json.dumps(payload["start"]), json.dumps(payload["destination"]), payload["algorithm"],
             json.dumps(payload["constraints"]), json.dumps(payload["drone"])),
        )
        return int(cur.lastrowid)

def fetch_mission(mission_id: int) -> sqlite3.Row | None:
    with connect() as conn:
        return conn.execute("SELECT * FROM missions WHERE id = ?", (mission_id,)).fetchone()

def fetch_missions() -> list[sqlite3.Row]:
    with connect() as conn:
        return conn.execute("SELECT * FROM missions ORDER BY datetime(created_at) DESC").fetchall()

def fetch_route(mission_id: int) -> list[dict[str, float]]:
    with connect() as conn:
        row = conn.execute(
            "SELECT route_json FROM mission_routes WHERE mission_id = ? AND is_current = 1 ORDER BY id DESC LIMIT 1",
            (mission_id,),
        ).fetchone()
    return json.loads(row[0]) if row else []

def replace_route(mission_id: int, route: list[dict[str, float]], created_at: str) -> None:
    with connect() as conn:
        conn.execute("UPDATE mission_routes SET is_current = 0 WHERE mission_id = ?", (mission_id,))
        conn.execute(
            "INSERT INTO mission_routes (mission_id, route_json, is_current, created_at) VALUES (?, ?, 1, ?)",
            (mission_id, json.dumps(route), created_at),
        )
        conn.execute("DELETE FROM waypoints WHERE mission_id = ?", (mission_id,))
        conn.executemany(
            "INSERT INTO waypoints (mission_id, point_json, sequence_no) VALUES (?, ?, ?)",
            [(mission_id, json.dumps(p), i) for i, p in enumerate(route)],
        )

def update_mission(mission_id: int, **fields: Any) -> None:
    if not fields:
        return
    keys = list(fields.keys())
    sql = ", ".join(f"{key} = ?" for key in keys)
    with connect() as conn:
        conn.execute(f"UPDATE missions SET {sql} WHERE id = ?", [fields[k] for k in keys] + [mission_id])

def insert_obstacle(mission_id: int, x: float, y: float, radius: float) -> None:
    with connect() as conn:
        conn.execute("INSERT INTO obstacles (mission_id, x, y, radius) VALUES (?, ?, ?, ?)", (mission_id, x, y, radius))

def fetch_obstacles(mission_id: int) -> list[sqlite3.Row]:
    with connect() as conn:
        return conn.execute("SELECT * FROM obstacles WHERE mission_id = ? AND active = 1", (mission_id,)).fetchall()

def upsert_simulation(mission_id: int, **fields: Any) -> None:
    with connect() as conn:
        row = conn.execute("SELECT id FROM simulation_sessions WHERE mission_id = ?", (mission_id,)).fetchone()
        if row:
            keys = list(fields.keys())
            sql = ", ".join(f"{k} = ?" for k in keys)
            conn.execute(f"UPDATE simulation_sessions SET {sql} WHERE id = ?", [fields[k] for k in keys] + [row[0]])
        else:
            defaults = {"progress_pct": 0, "battery_pct": 100, "distance_km": 0, "simulated_seconds": 0, "status": "READY"}
            defaults.update(fields)
            conn.execute(
                "INSERT INTO simulation_sessions (mission_id, progress_pct, battery_pct, distance_km, simulated_seconds, status) VALUES (?, ?, ?, ?, ?, ?)",
                (mission_id, defaults["progress_pct"], defaults["battery_pct"], defaults["distance_km"], defaults["simulated_seconds"], defaults["status"]),
            )

def fetch_simulation(mission_id: int) -> sqlite3.Row | None:
    with connect() as conn:
        return conn.execute("SELECT * FROM simulation_sessions WHERE mission_id = ?", (mission_id,)).fetchone()

def insert_telemetry(mission_id: int, telemetry: dict[str, Any]) -> None:
    with connect() as conn:
        conn.execute(
            """INSERT INTO telemetry (mission_id, battery_pct, speed_mps, altitude_m, distance_km, progress_pct,
            eta_sec, heading, current_waypoint, status, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (mission_id, telemetry["battery_pct"], telemetry["speed_mps"], telemetry["altitude_m"], telemetry["distance_km"],
             telemetry["progress_pct"], telemetry["eta_sec"], telemetry["heading"], telemetry["current_waypoint"],
             telemetry["status"], telemetry["updated_at"]),
        )

def fetch_latest_telemetry(mission_id: int) -> sqlite3.Row | None:
    with connect() as conn:
        return conn.execute("SELECT * FROM telemetry WHERE mission_id = ? ORDER BY id DESC LIMIT 1", (mission_id,)).fetchone()

def insert_event(mission_id: int, event_type: str, message: str, created_at: str) -> None:
    with connect() as conn:
        conn.execute("INSERT INTO events (mission_id, event_type, message, created_at) VALUES (?, ?, ?, ?)", (mission_id, event_type, message, created_at))
