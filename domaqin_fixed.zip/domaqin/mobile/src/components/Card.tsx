import React from 'react';
import { View, ViewProps } from 'react-native';
import { C, shadow } from '../constants/theme';
export function Card({children,style,...rest}:{children:React.ReactNode;style?:any}&ViewProps){return <View {...rest} style={[{backgroundColor:'rgba(11,18,32,.90)',borderWidth:1,borderColor:C.line,borderRadius:18,padding:16},shadow,style]}>{children}</View>}
