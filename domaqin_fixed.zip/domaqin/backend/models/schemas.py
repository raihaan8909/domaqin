from __future__ import annotations

from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field, field_validator

MissionType = Literal["Mapping", "Survey", "Inspection", "Search & Rescue Simulation", "Point-to-Point Navigation"]
AlgorithmName = Literal["A*", "Dijkstra", "RRT*", "Hybrid AI Planner"]

class Point(BaseModel):
    x: float = Field(ge=0, le=1)
    y: float = Field(ge=0, le=1)

class ConstraintConfig(BaseModel):
    max_distance_km: float = Field(default=8.0, gt=0, le=100)
    max_flight_time_min: float = Field(default=25, gt=0, le=240)
    battery_reserve_pct: float = Field(default=25, ge=0, le=90)
    safety_margin_m: float = Field(default=30, ge=0, le=500)
    max_speed_mps: float = Field(default=16, gt=0, le=60)
    max_altitude_m: float = Field(default=150, gt=1, le=500)

class DroneConfig(BaseModel):
    battery_capacity_mah: float = Field(default=5200, gt=1000, le=30000)
    starting_battery_pct: float = Field(default=100, ge=1, le=100)
    max_speed_mps: float = Field(default=16, gt=0, le=60)
    payload_weight_kg: float = Field(default=0.3, ge=0, le=10)
    power_consumption_w: float = Field(default=210, gt=10, le=2000)

class MissionCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    mission_type: MissionType
    description: str = Field(default="")
    start: Point
    destination: Point
    area: list[Point] = Field(default_factory=list)
    constraints: ConstraintConfig = Field(default_factory=ConstraintConfig)
    drone: DroneConfig = Field(default_factory=DroneConfig)
    algorithm: AlgorithmName = "Hybrid AI Planner"

class Obstacle(BaseModel):
    x: float = Field(ge=0, le=1)
    y: float = Field(ge=0, le=1)
    radius: float = Field(default=0.045, gt=0, le=0.25)

class RouteRequest(BaseModel):
    algorithm: AlgorithmName | None = None

class EventRequest(BaseModel):
    event_type: Literal["obstacle", "battery_drop", "restricted_zone", "block_route", "weather"]
    point: Point | None = None

class AssistantRequest(BaseModel):
    text: str = Field(min_length=1, max_length=1000)

class AssistantResponse(BaseModel):
    mission_type: MissionType
    optimization: Literal["Minimum Distance", "Minimum Time", "Balanced Cost"]
    battery_reserve: Literal["Low", "Medium", "High"]
    priority: Literal["Safety", "Efficiency", "Balanced"]
    interpreted_text: str

class Telemetry(BaseModel):
    battery_pct: float
    speed_mps: float
    altitude_m: float
    distance_km: float
    progress_pct: float
    eta_sec: int
    heading: str
    current_waypoint: int
    status: str
    updated_at: datetime

class MissionOut(BaseModel):
    id: int
    name: str
    mission_type: MissionType
    description: str
    status: str
    created_at: datetime
    start: Point
    destination: Point
    algorithm: AlgorithmName
    distance_km: float
    flight_time_min: float
    battery_usage_pct: float
    waypoints: int
    replans: int
    obstacles_avoided: int
    route: list[Point]

class PlanOut(BaseModel):
    mission: MissionOut
    nodes_evaluated: int
    candidate_paths: int
    obstacles_avoided: int
    planning_ms: float
    message: str

class SimulationOut(BaseModel):
    mission: MissionOut
    telemetry: Telemetry

class EventOut(BaseModel):
    mission: MissionOut
    telemetry: Telemetry
    event_message: str
    replanned: bool
