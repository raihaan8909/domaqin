from __future__ import annotations

import math
from typing import Iterable
from .algorithms.base import GridPoint

GRID_W = 30
GRID_H = 20


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def to_grid(p: dict[str, float], width: int = GRID_W, height: int = GRID_H) -> GridPoint:
    return int(round(clamp(p["x"], 0, 1) * (width - 1))), int(round(clamp(p["y"], 0, 1) * (height - 1)))


def to_norm(p: GridPoint, width: int = GRID_W, height: int = GRID_H) -> dict[str, float]:
    return {"x": round(p[0] / (width - 1), 4), "y": round(p[1] / (height - 1), 4)}


def route_length(route: Iterable[dict[str, float]]) -> float:
    points = list(route)
    return sum(math.hypot(points[i]["x"] - points[i - 1]["x"], points[i]["y"] - points[i - 1]["y"]) for i in range(1, len(points)))


def heading(a: dict[str, float], b: dict[str, float]) -> str:
    dx = b["x"] - a["x"]
    dy = b["y"] - a["y"]
    angle = (math.degrees(math.atan2(dy, dx)) + 360) % 360
    dirs = ["E", "NE", "N", "NW", "W", "SW", "S", "SE"]
    return dirs[int((angle + 22.5) // 45) % 8]
