from __future__ import annotations
import math, random
from .base import GridPoint, PlanResult, NeighborFn, CostFn


def rrt_star(start: GridPoint, goal: GridPoint, neighbors: NeighborFn, cost: CostFn, width: int, height: int, valid: callable, iterations: int = 650) -> PlanResult:
    rng = random.Random(42 + start[0] * 17 + goal[1] * 31)
    nodes: list[GridPoint] = [start]
    parent: dict[GridPoint, GridPoint] = {}
    best_goal: GridPoint | None = None
    for _ in range(iterations):
        sample = goal if rng.random() < 0.18 else (rng.randrange(width), rng.randrange(height))
        nearest = min(nodes, key=lambda p: math.dist(p, sample))
        sx = nearest[0] + int(max(-2, min(2, sample[0] - nearest[0])))
        sy = nearest[1] + int(max(-2, min(2, sample[1] - nearest[1])))
        nxt = (sx, sy)
        if not (0 <= sx < width and 0 <= sy < height) or not valid(nxt) or nxt in nodes:
            continue
        nearby = [p for p in nodes if math.dist(p, nxt) <= 3.5]
        candidate = min(nearby or [nearest], key=lambda p: cost(p, nxt) + (0 if p not in parent else 0.1))
        parent[nxt] = candidate
        nodes.append(nxt)
        if math.dist(nxt, goal) <= 2.0 and _line_valid(nxt, goal, valid):
            best_goal = nxt
            break
    if best_goal is None:
        return PlanResult([], len(nodes), 0, 0)
    path = [best_goal]
    while path[-1] != start:
        path.append(parent[path[-1]])
    path.reverse()
    if path[-1] != goal:
        path.append(goal)
    # local smoothing: replace unnecessary intermediate turns when direct edges are valid
    smoothed = [path[0]]
    anchor = 0
    while anchor < len(path) - 1:
        furthest = anchor + 1
        for j in range(anchor + 2, len(path)):
            if _line_valid(path[anchor], path[j], valid):
                furthest = j
            else:
                break
        smoothed.append(path[furthest])
        anchor = furthest
    return PlanResult(smoothed, len(nodes), max(1, len(nodes) // 10), 0)


def _line_valid(a: GridPoint, b: GridPoint, valid: callable) -> bool:
    steps = max(abs(b[0] - a[0]), abs(b[1] - a[1])) * 2 + 1
    for i in range(steps + 1):
        t = i / max(steps, 1)
        p = (round(a[0] + (b[0] - a[0]) * t), round(a[1] + (b[1] - a[1]) * t))
        if not valid(p):
            return False
    return True
