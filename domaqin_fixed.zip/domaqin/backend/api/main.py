from __future__ import annotations

from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from backend.database.db import init_db
from backend.models.schemas import MissionCreate, MissionOut, PlanOut, SimulationOut, EventRequest, EventOut, AssistantRequest, AssistantResponse, RouteRequest, Telemetry
from backend.services.mission_service import create_mission, list_missions, get_mission, plan_mission, row_to_dict, plan_return_home
from backend.simulation.engine import tick, latest
from backend.database import db
from backend.services.assistant import parse_request
from datetime import datetime, timezone

@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield

app = FastAPI(title="DOMAQIN AI Mission Planner API", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

@app.get("/health")
def health(): return {"status": "AI SYSTEM ONLINE"}

@app.post("/missions", response_model=MissionOut)
def post_mission(payload: MissionCreate):
    try: return create_mission(payload)
    except Exception as exc: raise HTTPException(400, str(exc))

@app.get("/missions", response_model=list[MissionOut])
def get_missions(): return list_missions()

@app.get("/missions/{mission_id}", response_model=MissionOut)
def get_one(mission_id: int):
    mission = get_mission(mission_id)
    if not mission: raise HTTPException(404, "Mission not found")
    return mission

@app.post("/missions/{mission_id}/plan", response_model=PlanOut)
def post_plan(mission_id: int, req: RouteRequest):
    try: return plan_mission(mission_id, req.algorithm)
    except KeyError as exc: raise HTTPException(404, str(exc))
    except ValueError as exc: raise HTTPException(422, str(exc))

@app.post("/missions/{mission_id}/simulate", response_model=SimulationOut)
def post_simulate(mission_id: int):
    try:
        telemetry = tick(mission_id)
        return {"mission": get_mission(mission_id), "telemetry": telemetry}
    except KeyError as exc: raise HTTPException(404, str(exc))
    except ValueError as exc: raise HTTPException(422, str(exc))

@app.post("/missions/{mission_id}/replan", response_model=PlanOut)
def post_replan(mission_id: int, req: RouteRequest):
    try:
        mission = get_mission(mission_id)
        current = plan_mission(mission_id, req.algorithm or mission["algorithm"] if mission else req.algorithm)
        db.update_mission(mission_id, replans=(mission["replans"] + 1) if mission else 1, status="REPLANNED")
        current["mission"] = get_mission(mission_id)
        current["message"] = "Route successfully replanned."
        return current
    except KeyError as exc: raise HTTPException(404, str(exc))
    except ValueError as exc: raise HTTPException(422, str(exc))

@app.get("/missions/{mission_id}/telemetry", response_model=Telemetry)
def get_telemetry(mission_id: int):
    try: return latest(mission_id)
    except KeyError as exc: raise HTTPException(404, str(exc))
    except ValueError as exc: raise HTTPException(422, str(exc))

@app.delete("/missions/{mission_id}")
def delete_one(mission_id: int):
    mission = get_mission(mission_id)
    if not mission: raise HTTPException(404, "Mission not found")
    with db.connect() as conn:
        conn.execute("DELETE FROM telemetry WHERE mission_id = ?", (mission_id,))
        conn.execute("DELETE FROM events WHERE mission_id = ?", (mission_id,))
        conn.execute("DELETE FROM simulation_sessions WHERE mission_id = ?", (mission_id,))
        conn.execute("DELETE FROM obstacles WHERE mission_id = ?", (mission_id,))
        conn.execute("DELETE FROM waypoints WHERE mission_id = ?", (mission_id,))
        conn.execute("DELETE FROM mission_routes WHERE mission_id = ?", (mission_id,))
        conn.execute("DELETE FROM missions WHERE id = ?", (mission_id,))
    return {"deleted": mission_id}

@app.post("/missions/{mission_id}/events", response_model=EventOut)
def post_event(mission_id: int, payload: EventRequest):
    mission = get_mission(mission_id)
    if not mission: raise HTTPException(404, "Mission not found")
    if payload.event_type in {"obstacle", "block_route", "weather", "restricted_zone"}:
        p = payload.point or (mission["route"][max(1, len(mission["route"])//2)] if mission["route"] else mission["destination"])
        radius = 0.055 if payload.event_type != "weather" else 0.08
        if payload.event_type == "restricted_zone": radius = 0.075
        db.insert_obstacle(mission_id, p["x"], p["y"], radius) if isinstance(p, dict) else db.insert_obstacle(mission_id, p.x, p.y, radius)
    elif payload.event_type == "battery_drop":
        sim = db.fetch_simulation(mission_id)
        if sim:
            new_battery = max(0, float(sim["battery_pct"]) - 28)
            db.upsert_simulation(mission_id, battery_pct=new_battery)
            if new_battery < 20 and mission["route"]:
                plan_return_home(mission_id) 
    msgs = {
        "obstacle": "OBSTACLE DETECTED — AI REPLANNING…", "block_route": "ROUTE BLOCKED — recalculating safe corridor…",
        "restricted_zone": "RESTRICTED ZONE ACTIVE — recalculating…", "weather": "WEATHER DEGRADATION — increasing route cost…",
        "battery_drop": "BATTERY DROP SIMULATED — evaluating reserve…"
    }
    db.insert_event(mission_id, payload.event_type, msgs[payload.event_type], datetime.now(timezone.utc).isoformat())
    replanned = payload.event_type != "battery_drop"
    if replanned:
        before = mission["replans"]
        plan = plan_mission(mission_id, mission["algorithm"])
        db.update_mission(mission_id, replans=before + 1, status="REPLANNED")
    telemetry = latest(mission_id)
    return {"mission": get_mission(mission_id), "telemetry": telemetry, "event_message": msgs[payload.event_type], "replanned": replanned}

@app.post("/assistant/parse", response_model=AssistantResponse)
def assistant(payload: AssistantRequest): return parse_request(payload.text)
