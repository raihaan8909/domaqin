from backend.database import db
from backend.models.schemas import MissionCreate
from backend.services.mission_service import create_mission, plan_mission
from backend.simulation.engine import tick
from backend.services.mission_service import plan_return_home


def fresh_mission():
    db.init_db()
    m = create_mission(MissionCreate(name='Event Test', mission_type='Mapping', description='', start={'x':.1,'y':.8}, destination={'x':.9,'y':.2}, area=[], algorithm='A*'))
    plan_mission(m['id'])
    return m['id']


def test_simulation_consumes_battery_from_progress():
    mid = fresh_mission()
    t = tick(mid, 10)
    assert t['progress_pct'] == 10
    assert t['battery_pct'] < 100
    assert t['distance_km'] > 0


def test_return_home_reuses_planner():
    mid = fresh_mission()
    for _ in range(8): tick(mid, 10)
    mission = db.fetch_mission(mid)
    sim = db.fetch_simulation(mid)
    assert mission and sim
    db.upsert_simulation(mid, battery_pct=15)
    route = plan_return_home(mid)
    assert route and route[0]['x'] != route[-1]['x'] or route and route[0]['y'] != route[-1]['y']
    assert db.fetch_simulation(mid)['status'] == 'RETURNING HOME'
