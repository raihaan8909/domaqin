import React from 'react';
import { Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../constants/theme';
export function Logo({small=false}:{small?:boolean}){return <View style={{flexDirection:'row',alignItems:'center',gap:small?8:10}}><View style={{width:small?30:38,height:small?30:38,borderRadius:10,borderWidth:1,borderColor:C.cyan,alignItems:'center',justifyContent:'center',backgroundColor:'#071422'}}><Ionicons name="navigate" size={small?16:20} color={C.cyan}/></View><View><Text style={{color:C.text,fontSize:small?15:18,fontWeight:'800',letterSpacing:2}}>DOMAQIN</Text>{!small && <Text style={{color:C.muted,fontSize:8,letterSpacing:1.5,marginTop:2}}>AUTONOMOUS SYSTEMS</Text>}</View></View>}
