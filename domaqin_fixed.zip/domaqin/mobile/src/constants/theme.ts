export const C = {
  bg: '#050914',
  panel: '#0B1220',
  panel2: '#0F1828',
  line: '#1B2A3E',
  text: '#F4F8FF',
  muted: '#8EA1B7',
  cyan: '#29C7FF',
  cyan2: '#8DE6FF',
  green: '#46E6A4',
  amber: '#FFB454',
  red: '#FF657A',
  orange: '#FF895E',
  black: '#02050B',
};
export const shadow = { shadowColor: '#000', shadowOffset: {width:0,height:10}, shadowOpacity: .22, shadowRadius: 24, elevation: 12 };
