from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Iterable

GridPoint = tuple[int, int]

@dataclass
class PlanResult:
    path: list[GridPoint]
    nodes_evaluated: int
    candidate_paths: int
    obstacles_avoided: int

NeighborFn = Callable[[GridPoint], Iterable[GridPoint]]
CostFn = Callable[[GridPoint, GridPoint], float]
