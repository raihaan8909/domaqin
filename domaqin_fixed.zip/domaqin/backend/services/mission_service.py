from __future__ import annotations
from datetime import datetime, timezone
import math
from backend.database import db
from backend.models.schemas import MissionCreate
from backend.planner.planner import GridPlanner, PlannerInput
from backend.planner.geometry import route_length


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def row_to_dict(row, route=None) -> dict:
    import json
    return {
        "id": row["id"], "name": row["name"], "mission_type": row["mission_type"], "description": row["description"],
        "status": row["status"], "created_at": row["created_at"], "start": json.loads(row["start_json"]),
        "destination": json.loads(row["destination_json"]), "algorithm": row["algorithm"], "distance_km": row["distance_km"],
        "flight_time_min": row["flight_time_min"], "battery_usage_pct": row["battery_usage_pct"], "waypoints": row["waypoints"],
        "replans": row["replans"], "obstacles_avoided": row["obstacles_avoided"], "route": route if route is not None else db.fetch_route(row["id"]),
    }


def create_mission(mission: MissionCreate):
    payload = mission.model_dump()
    mission_id = db.insert_mission(payload, now_iso())
    row = db.fetch_mission(mission_id)
    return row_to_dict(row)


def list_missions():
    return [row_to_dict(row) for row in db.fetch_missions()]


def get_mission(mission_id: int):
    row = db.fetch_mission(mission_id)
    if not row: return None
    return row_to_dict(row)


def plan_mission(mission_id: int, algorithm: str | None = None):
    row = db.fetch_mission(mission_id)
    if not row: raise KeyError("Mission not found")
    import json
    obstacles = [{"x": r["x"], "y": r["y"], "radius": r["radius"]} for r in db.fetch_obstacles(mission_id)]
    c = json.loads(row["constraints_json"]); d = json.loads(row["drone_json"])
    chosen = algorithm or row["algorithm"]
    planner = GridPlanner(PlannerInput(json.loads(row["start_json"]), json.loads(row["destination_json"]), obstacles, [], c["safety_margin_m"], c["battery_reserve_pct"], chosen, d["payload_weight_kg"], d["max_speed_mps"]))
    started = datetime.now().timestamp()
    result = planner.plan()
    route = planner.normalize_path(result.path)
    dist = route_length(route) * 5.5
    speed = min(d["max_speed_mps"], c["max_speed_mps"])
    flight_min = (dist * 1000 / speed) / 60
    battery_energy_wh = max(1.0, (d["battery_capacity_mah"] / 1000) * 11.1)
    base_consumption = ((flight_min / 60) * d["power_consumption_w"] / battery_energy_wh) * 100
    battery_usage = min(100, max(2, base_consumption * (1 + d["payload_weight_kg"] * 0.1)))
    if dist > c["max_distance_km"] or flight_min > c["max_flight_time_min"] or battery_usage > 100 - c["battery_reserve_pct"]:
        raise ValueError("The generated route exceeds one or more mission constraints.")
    db.replace_route(mission_id, route, now_iso())
    db.update_mission(mission_id, status="PLANNED", algorithm=chosen, distance_km=round(dist, 3), flight_time_min=round(flight_min, 2), battery_usage_pct=round(battery_usage, 2), waypoints=len(route), obstacles_avoided=result.obstacles_avoided)
    db.upsert_simulation(mission_id, progress_pct=0, battery_pct=d["starting_battery_pct"], distance_km=0, simulated_seconds=0, status="READY")
    return {
        "mission": get_mission(mission_id), "nodes_evaluated": result.nodes_evaluated, "candidate_paths": result.candidate_paths,
        "obstacles_avoided": result.obstacles_avoided, "planning_ms": round((datetime.now().timestamp() - started) * 1000, 2),
        "message": "Mission generated."
    }


def plan_return_home(mission_id: int):
    import json
    row = db.fetch_mission(mission_id)
    if not row: raise KeyError("Mission not found")
    route = db.fetch_route(mission_id)
    sim = db.fetch_simulation(mission_id)
    c = json.loads(row["constraints_json"]); d = json.loads(row["drone_json"])
    if not route or not sim: return None
    idx = min(max(0, int(round((len(route)-1) * float(sim["progress_pct"]) / 100))), len(route)-1)
    start = route[idx]
    home = json.loads(row["start_json"])
    planner = GridPlanner(PlannerInput(start, home, [{"x":r["x"],"y":r["y"],"radius":r["radius"]} for r in db.fetch_obstacles(mission_id)], [], c["safety_margin_m"], 20, "Hybrid AI Planner", d["payload_weight_kg"], d["max_speed_mps"]))
    result = planner.plan()
    rth = planner.normalize_path(result.path)
    db.replace_route(mission_id, rth, now_iso())
    db.update_mission(mission_id, status="LOW BATTERY • RETURN TO HOME", distance_km=round(route_length(rth)*5.5,3), waypoints=len(rth), obstacles_avoided=result.obstacles_avoided)
    db.upsert_simulation(mission_id, progress_pct=0, distance_km=0, status="RETURNING HOME")
    return rth
