from backend.services.assistant import parse_request

def test_parser_is_deterministic():
    a = parse_request("inspection safety")
    b = parse_request("inspection safety")
    assert a == b
