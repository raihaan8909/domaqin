# DOMAQIN Architecture

## Runtime

The mobile app is a React Native + TypeScript Expo client. It owns navigation, interaction, simulation animation and presentation. The FastAPI service owns mission persistence, route planning, simulation state and event-driven replanning.

## Planning

1. Mission JSON is validated through Pydantic.
2. The planner normalizes the map to a 30×20 grid.
3. Obstacles and restricted areas become blocked/costed grid cells.
4. The selected planner generates a path.
5. The route is normalized back to 0..1 coordinates for the mobile visualization.
6. Distance, time and battery usage are computed from route geometry and drone configuration.
7. Mission statistics are persisted.

## Simulation

Simulation progress is advanced in controlled deterministic ticks. Battery consumption is proportional to the stored route energy estimate and progress, never random telemetry. Speed, altitude, distance, waypoint index, heading and ETA are derived from the simulation state.

## Replanning

Events can add an obstacle/cost layer or reduce battery state. Obstacle-style events call the planner again. When the battery drops below the critical threshold, a return-to-home route is generated from the current simulated waypoint to the mission start.
