from backend.services.assistant import parse_request

def test_assistant_parser():
    result = parse_request("Plan a mapping mission with high battery reserve and minimum distance")
    assert result.mission_type == "Mapping"
    assert result.optimization == "Minimum Distance"
    assert result.battery_reserve == "High"
