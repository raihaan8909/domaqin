export type Point = { x: number; y: number };
export type Algorithm = 'A*' | 'Dijkstra' | 'RRT*' | 'Hybrid AI Planner';
export type MissionType = 'Mapping' | 'Survey' | 'Inspection' | 'Search & Rescue Simulation' | 'Point-to-Point Navigation';
export type Mission = {
  id: number; name: string; mission_type: MissionType; description: string; status: string; created_at: string;
  start: Point; destination: Point; algorithm: Algorithm; distance_km: number; flight_time_min: number;
  battery_usage_pct: number; waypoints: number; replans: number; obstacles_avoided: number; route: Point[];
};
export type Telemetry = {
  battery_pct: number; speed_mps: number; altitude_m: number; distance_km: number; progress_pct: number;
  eta_sec: number; heading: string; current_waypoint: number; status: string; updated_at: string;
};
export const SAMPLE_MISSION: Mission = {
  id: 0, name: 'Demo Ridge Survey', mission_type: 'Mapping', description: 'Civilian terrain mapping simulation.', status: 'PLANNED',
  created_at: new Date().toISOString(), start: {x:.1,y:.78}, destination:{x:.9,y:.18}, algorithm:'Hybrid AI Planner',
  distance_km: 5.8, flight_time_min: 8.2, battery_usage_pct: 34, waypoints: 12, replans: 0, obstacles_avoided: 5,
  route: [{x:.1,y:.78},{x:.17,y:.68},{x:.25,y:.62},{x:.33,y:.54},{x:.41,y:.5},{x:.5,y:.42},{x:.58,y:.36},{x:.67,y:.31},{x:.75,y:.26},{x:.83,y:.22},{x:.9,y:.18}]
};
