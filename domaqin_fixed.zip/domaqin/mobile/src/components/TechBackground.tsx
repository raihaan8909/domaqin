import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, View } from 'react-native';
import { C } from '../constants/theme';

export function TechBackground({intensity=1}:{intensity?:number}) {
  const pulse = useRef(new Animated.Value(0)).current;
  useEffect(()=>{ const loop=Animated.loop(Animated.timing(pulse,{toValue:1,duration:6000,easing:Easing.inOut(Easing.ease),useNativeDriver:true})); loop.start(); return ()=>loop.stop(); },[]);
  const opacity = pulse.interpolate({inputRange:[0,.5,1],outputRange:[.18,.32,.18]});
  return <View pointerEvents="none" style={StyleSheet.absoluteFill}>
    <View style={styles.gradientTop}/>
    <Animated.View style={[styles.scan,{opacity, transform:[{translateY:pulse.interpolate({inputRange:[0,1],outputRange:[-80,520]})}]}]}/>
    {Array.from({length:12}).map((_,i)=><View key={'v'+i} style={[styles.gridV,{left:`${i*9}%` as any,opacity:.11*intensity}]}/>)}
    {Array.from({length:18}).map((_,i)=><View key={'h'+i} style={[styles.gridH,{top:`${i*7}%` as any,opacity:.09*intensity}]}/>)}
    {Array.from({length:24}).map((_,i)=><View key={'p'+i} style={[styles.dot,{left:`${(i*37)%97}%` as any,top:`${(i*19)%91}%` as any,opacity:.2*intensity}]}/>)}
  </View>
}
const styles=StyleSheet.create({gradientTop:{position:'absolute',top:0,left:0,right:0,height:260,backgroundColor:'#0B1D32',opacity:.38},scan:{position:'absolute',left:0,right:0,height:2,backgroundColor:C.cyan},gridV:{position:'absolute',top:0,bottom:0,width:1,backgroundColor:C.cyan},gridH:{position:'absolute',left:0,right:0,height:1,backgroundColor:C.cyan},dot:{position:'absolute',width:3,height:3,borderRadius:3,backgroundColor:C.cyan2}});
