# DOMAQIN – Implementation and Screenshot Guide

## 1. Requirements
- Python 3.10 or newer
- Node.js LTS and npm
- VS Code (recommended)
- A modern browser; Android Studio/Expo Go is optional

## 2. Extract and open
Extract `domaqin_fixed.zip`. Open the extracted `domaqin` folder in VS Code. Open two terminals in that folder.

## 3. Start the FastAPI backend (Terminal 1)
```bash
python -m venv .venv
# Windows PowerShell:
.venv\\Scripts\\Activate.ps1
# macOS/Linux:
source .venv/bin/activate

pip install -r backend/requirements.txt
python -m uvicorn backend.api.main:app --reload --host 0.0.0.0 --port 8000
```
Check `http://127.0.0.1:8000/health` (should return `{"status":"AI SYSTEM ONLINE"}`) and open `http://127.0.0.1:8000/docs` to view the API.

## 4. Start the Expo frontend (Terminal 2)
```bash
cd mobile
npm install
npm run web
```
Expo will show a local URL, normally `http://localhost:8081`. Open it in Chrome. To use Expo Go instead, run `npx expo start` and scan the QR code.

### Connect a phone or Android emulator
The default API URL is localhost, which is correct for the web app on the same computer.
- Android emulator: set `EXPO_PUBLIC_API_URL=http://10.0.2.2:8000` before starting Expo.
- Physical phone: use your computer's LAN IPv4 address, e.g. `http://192.168.1.20:8000`. The phone and computer must be on the same Wi-Fi network and the firewall must allow port 8000.

PowerShell example (run inside `mobile`):
```powershell
$env:EXPO_PUBLIC_API_URL="http://192.168.1.20:8000"
npm start
```
macOS/Linux example:
```bash
EXPO_PUBLIC_API_URL=http://192.168.1.20:8000 npm start
```
Replace the example IP with your computer's actual LAN IP.

## 5. Demonstrate the application
1. Open **Home** and capture the dashboard.
2. Open **Missions** to show mission history.
3. Select **Create Mission**, enter a name, choose a mission type, and save.
4. Open **Planner**, select an algorithm (A*, Dijkstra, RRT*, or Hybrid AI Planner), and generate a route.
5. Open **Simulation** and start the simulation. Use the event controls to demonstrate obstacle/battery events if available.
6. Open **Analytics** after running a mission to show stored mission statistics.
7. Open `http://127.0.0.1:8000/docs` for an additional screenshot of the REST API.

The Home screen's **RUN DEMO** action can also create, plan, and simulate a sample civilian mapping mission automatically. Keep the backend running so the app can save mission data.

## 6. Suggested report screenshots
- Figure 1: DOMAQIN Home dashboard
- Figure 2: Mission list / mission history
- Figure 3: Create Mission form
- Figure 4: Route planning screen showing selected algorithm and generated path
- Figure 5: Simulation screen showing telemetry/progress
- Figure 6: Analytics screen after a completed simulation
- Figure 7: FastAPI Swagger documentation (`/docs`)

For clean screenshots, maximize the browser, use a consistent zoom (100%), wait for charts/telemetry to finish loading, and avoid showing terminal windows or personal information. On Windows use `Win + Shift + S`; on macOS use `Shift + Cmd + 4`; on most Linux desktops use `PrtSc`.

## 7. Run backend tests
From the project root (the folder containing `backend/`):
```bash
python -m pytest -q backend/tests
```
Expected result for this corrected package: **12 passed**.

## Notes
- This project is a simulation and planning demonstrator, not a real-drone flight-control system.
- The map uses a normalized simulation grid, not live geographic maps or live sensor/weather feeds.
- If Expo reports a dependency/version conflict, share the full terminal error before changing package versions; do not randomly upgrade Expo, React, or React Native independently.
