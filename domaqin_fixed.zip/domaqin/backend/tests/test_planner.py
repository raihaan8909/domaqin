import pytest
from backend.planner.planner import GridPlanner, PlannerInput


def planner(algo="A*", obstacles=None):
    return GridPlanner(PlannerInput(
        start={"x":0.08,"y":0.5}, destination={"x":0.92,"y":0.5}, obstacles=obstacles or [], restricted=[],
        safety_margin=30, battery_reserve_pct=30, algorithm=algo, payload_weight_kg=0.3, speed_mps=12
    ))

@pytest.mark.parametrize("algo", ["A*", "Dijkstra", "RRT*", "Hybrid AI Planner"])
def test_algorithms_reach_goal(algo):
    p = planner(algo)
    result = p.plan()
    assert result.path[0] == p.start
    assert result.path[-1] == p.goal
    assert result.nodes_evaluated > 0


def test_obstacle_is_avoided():
    p = planner("A*", [{"x":0.5,"y":0.5,"radius":0.09}])
    result = p.plan()
    assert all(point not in p.blocked for point in result.path)


def test_no_route_when_full_barrier():
    obstacles = [{"x":0.5,"y":y/19,"radius":0.12} for y in range(20)]
    p = planner("A*", obstacles)
    with pytest.raises(ValueError): p.plan()


def test_start_inside_obstacle_is_rejected():
    p = planner("A*", [{"x":0.08,"y":0.5,"radius":0.08}])
    with pytest.raises(ValueError, match="start point"):
        p.plan()


def test_rrt_star_path_edges_stay_in_free_space():
    p = planner("RRT*", [{"x":0.5,"y":0.5,"radius":0.08}])
    result = p.plan()
    from backend.planner.algorithms.rrt_star import _line_valid
    assert all(_line_valid(a, b, p.valid) for a, b in zip(result.path, result.path[1:]))
