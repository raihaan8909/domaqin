from __future__ import annotations
import heapq, math
from .base import GridPoint, PlanResult, NeighborFn, CostFn


def astar(start: GridPoint, goal: GridPoint, neighbors: NeighborFn, cost: CostFn) -> PlanResult:
    frontier: list[tuple[float, int, GridPoint]] = [(0.0, 0, start)]
    came: dict[GridPoint, GridPoint] = {}
    g: dict[GridPoint, float] = {start: 0.0}
    visited = 0
    counter = 1
    while frontier:
        _, _, current = heapq.heappop(frontier)
        visited += 1
        if current == goal:
            path = [current]
            while path[-1] != start:
                path.append(came[path[-1]])
            path.reverse()
            return PlanResult(path, visited, max(1, visited // 6), 0)
        for nxt in neighbors(current):
            ng = g[current] + cost(current, nxt)
            if ng < g.get(nxt, math.inf):
                came[nxt] = current
                g[nxt] = ng
                h = math.hypot(goal[0] - nxt[0], goal[1] - nxt[1])
                heapq.heappush(frontier, (ng + h, counter, nxt))
                counter += 1
    return PlanResult([], visited, 0, 0)
