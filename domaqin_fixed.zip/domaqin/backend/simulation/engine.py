from __future__ import annotations
import math
from datetime import datetime, timezone
from backend.database import db
from backend.planner.geometry import heading


def _telemetry_for(row, sim, route):
    import json
    drone = json.loads(row["drone_json"])
    speed = min(drone["max_speed_mps"], 16.0)
    progress = float(sim["progress_pct"])
    total_km = float(row["distance_km"])
    distance = total_km * progress / 100
    route_index = min(max(0, int(round((len(route)-1) * progress / 100))), max(0, len(route)-1))
    current = route[route_index] if route else json.loads(row["start_json"])
    nxt = route[min(route_index + 1, len(route)-1)] if route else json.loads(row["destination_json"])
    battery = float(sim["battery_pct"])
    eta = max(0, int(((100 - progress) / 100) * float(row["flight_time_min"]) * 60))
    status = "COMPLETE" if progress >= 100 else "RUNNING"
    return {
        "battery_pct": round(battery, 1), "speed_mps": round(speed, 1), "altitude_m": min(120.0, 60 + 60 * progress / 100),
        "distance_km": round(distance, 3), "progress_pct": round(progress, 1), "eta_sec": eta,
        "heading": heading(current, nxt) if route else "N", "current_waypoint": route_index + 1, "status": status,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }


def ensure_ready(mission_id: int):
    row = db.fetch_mission(mission_id)
    if not row: raise KeyError("Mission not found")
    route = db.fetch_route(mission_id)
    if len(route) < 2: raise ValueError("Mission must be planned before simulation starts.")
    sim = db.fetch_simulation(mission_id)
    if not sim:
        import json
        d = json.loads(row["drone_json"])
        db.upsert_simulation(mission_id, progress_pct=0, battery_pct=d["starting_battery_pct"], status="READY")
        sim = db.fetch_simulation(mission_id)
    return row, sim, route


def tick(mission_id: int, progress_step: float = 4.0):
    row, sim, route = ensure_ready(mission_id)
    import json
    d = json.loads(row["drone_json"])
    new_progress = min(100.0, float(sim["progress_pct"]) + progress_step)
    battery_drop = float(row["battery_usage_pct"]) * progress_step / 100
    new_battery = max(0.0, float(sim["battery_pct"]) - battery_drop)
    status = "COMPLETE" if new_progress >= 100 else "RUNNING"
    db.upsert_simulation(mission_id, progress_pct=new_progress, battery_pct=new_battery, distance_km=float(row["distance_km"]) * new_progress / 100, simulated_seconds=float(sim["simulated_seconds"]) + 4, status=status)
    telemetry = _telemetry_for(row, db.fetch_simulation(mission_id), route)
    db.insert_telemetry(mission_id, telemetry)
    db.update_mission(mission_id, status="COMPLETED" if new_progress >= 100 else "SIMULATING")
    return telemetry


def latest(mission_id: int):
    row = db.fetch_mission(mission_id)
    if not row: raise KeyError("Mission not found")
    sim = db.fetch_simulation(mission_id)
    route = db.fetch_route(mission_id)
    if not sim: ensure_ready(mission_id); sim = db.fetch_simulation(mission_id)
    telemetry = _telemetry_for(row, sim, route)
    return telemetry
