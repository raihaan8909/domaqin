from __future__ import annotations
import re
from backend.models.schemas import AssistantResponse


def parse_request(text: str) -> AssistantResponse:
    t = text.lower()
    mission_type = "Mapping" if "mapping" in t or "map" in t else "Survey" if "survey" in t else "Inspection" if "inspection" in t else "Search & Rescue Simulation" if "search" in t or "rescue" in t else "Point-to-Point Navigation"
    optimization = "Minimum Distance" if "minimum distance" in t or "shortest" in t or "distance" in t else "Minimum Time" if "fast" in t or "minimum time" in t else "Balanced Cost"
    battery_reserve = "High" if "high battery" in t or "high reserve" in t or "maximum reserve" in t else "Low" if "low battery" in t or "low reserve" in t else "Medium"
    priority = "Safety" if "safety" in t or "safe" in t or "high battery" in t or "high reserve" in t else "Efficiency" if "efficient" in t or "speed" in t or "minimum distance" in t else "Balanced"
    return AssistantResponse(mission_type=mission_type, optimization=optimization, battery_reserve=battery_reserve, priority=priority, interpreted_text=f"Parsed mission intent: {mission_type}; optimize for {optimization.lower()}; {battery_reserve.lower()} battery reserve; {priority.lower()} priority.")
