# DOMAQIN

## AI-Powered Autonomous Drone Mission Planner

DOMAQIN is a mobile-first, simulation-first autonomous systems demonstration for civilian drone navigation research. It combines deterministic path-planning algorithms, an explainable AI intent parser, a simulated flight engine, live telemetry, dynamic replanning, mission history, and analytics in a premium dark interface.

> **Safety boundary:** DOMAQIN is a research/education simulation. It does not control a physical drone and contains no weapon control, target engagement, harmful payload deployment, airspace bypass, or unauthorized surveillance features.

## Technology

- **Mobile:** React Native + TypeScript + Expo SDK 57
- **Backend:** Python FastAPI + Pydantic
- **Planning:** A*, Dijkstra, RRT*, Hybrid AI Planner
- **Persistence:** SQLite
- **Visualization:** Custom React Native map/grid rendering and animations

Expo's current documentation lists SDK 57 with React Native 0.86 and TypeScript support. The current Expo SDK 57 requirement of Node 22.13+ is compatible with this project on Node 22.16+. See the official Expo docs when setting up a local environment.

## Features implemented

### Mobile experience

- Premium dark autonomous-systems UI
- Animated technical grid / scan background
- Bottom navigation: Home, Missions, Planner, Simulation, Analytics
- Mission creation wizard
- Interactive simulated map with pan, zoom, route, waypoints, obstacles, start/destination markers and drone marker
- Accessible coordinate adjustment controls for mission placement
- Natural-language mission assistant with local deterministic parser fallback
- Planning animation: environment analysis → candidate evaluation → cost calculation → optimization
- Live flight simulation with telemetry derived from simulation state
- Dynamic obstacle, restricted-zone, route-block, weather and battery events
- Replanning with previous route shown in grey and updated route highlighted
- Low-battery return-to-home simulation
- Mission details, replay, duplicate and delete
- Analytics charts derived from stored missions
- Settings surface for simulation/project preferences

### Backend

Implemented endpoints:

- `GET /health`
- `POST /missions`
- `GET /missions`
- `GET /missions/{id}`
- `DELETE /missions/{id}`
- `POST /missions/{id}/plan`
- `POST /missions/{id}/simulate`
- `POST /missions/{id}/replan`
- `GET /missions/{id}/telemetry`
- `POST /missions/{id}/events`
- `POST /assistant/parse`

SQLite stores missions, routes, waypoints, obstacles, simulation sessions, telemetry, and events.

## Project structure

```text
domaqin/
├── mobile/
│   ├── App.tsx
│   ├── app.json
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       ├── components/
│       ├── constants/
│       ├── models/
│       ├── screens/
│       ├── services/
│       └── utils/
├── backend/
│   ├── api/
│   ├── database/
│   ├── models/
│   ├── planner/
│   │   └── algorithms/
│   ├── services/
│   ├── simulation/
│   ├── tests/
│   └── requirements.txt
├── docs/
├── .env.example
└── README.md
```

## Setup

### 1. Backend

```bash
cd domaqin
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\\Scripts\\activate
pip install -r backend/requirements.txt
```

Run the API:

```bash
PYTHONPATH=. uvicorn backend.api.main:app --reload --host 0.0.0.0 --port 8000
```

API docs are available at `http://127.0.0.1:8000/docs`.

### 2. Mobile app

```bash
cd mobile
npm install
npm start
```

Then use Expo Go on a device, an Android emulator, an iOS simulator, or the web target.

### Backend URL configuration

The mobile app reads `EXPO_PUBLIC_API_URL` and falls back to `http://localhost:8000`.

For an Android emulator, use:

```bash
EXPO_PUBLIC_API_URL=http://10.0.2.2:8000 npm start
```

For a physical device, use the development machine's LAN address, for example:

```bash
EXPO_PUBLIC_API_URL=http://192.168.1.20:8000 npm start
```

Do not put secrets in the mobile app. Optional future LLM credentials belong in server-side environment variables.

## Running tests

Backend tests:

```bash
PYTHONPATH=. pytest -q backend/tests
```

The test suite covers:

- A*
- Dijkstra
- RRT*
- Hybrid planner
- Obstacle avoidance
- No-route constraints
- Assistant parsing
- Deterministic simulation battery consumption
- Return-to-home replanning

## Demo mode

Tap **RUN DEMO** on Home or Missions. The automated demonstration:

1. Creates a civilian mapping mission.
2. Runs the planner.
3. Shows planning diagnostics.
4. Starts simulated flight.
5. Updates real telemetry from simulation progress.
6. Introduces a simulated obstacle.
7. Replans the route.
8. Continues the simulation.
9. Completes the mission.
10. Leaves the stored mission available to Analytics and Mission History.

## AI architecture

The project intentionally separates language interpretation from mathematical path planning.

```text
Natural-language request
          │
          ▼
Local deterministic intent parser
          │
          ├── mission type
          ├── optimization objective
          ├── battery reserve
          └── priority
          │
          ▼
Structured mission parameters
          │
          ▼
Deterministic planner
   ┌──────┼────────┬──────────────┐
   ▼      ▼        ▼              ▼
  A*   Dijkstra   RRT*   Hybrid AI Planner
   │      │        │              │
   └──────┴────────┴──────────────┘
                    │
                    ▼
       Route + cost diagnostics
                    │
                    ▼
          Simulation / telemetry
                    │
           environment event
                    │
                    ▼
             Dynamic replanning
```

The planner cost combines distance, obstacle proximity, restricted-zone costs, battery-reserve pressure, payload factor and path complexity. Path planning is deterministic; the assistant does not masquerade as a mathematical planner.

## Known limitations

- The map is a normalized local simulation grid rather than live geospatial data.
- Weather and restricted-zone events are represented as simulation cost/obstacle layers rather than real sensor feeds.
- Analytics are intentionally based only on simulations stored by the current local SQLite database.
- The mobile dependency installation could not be fully completed in the isolated build environment used for this artifact, so the backend was executed end-to-end and the TypeScript source was statically syntax-checked with the available compiler. A normal development machine should run `npm install` before launch.

## Future scope

- Optional OpenAI-compatible server-side mission interpretation
- Terrain elevation layers and 3D simulation views
- More sophisticated continuous-space RRT* smoothing
- Multi-drone coordination simulation
- Exportable mission reports
- WebSocket telemetry streaming
- Sensor-noise and uncertainty models
- More detailed energy models based on wind and climb rate

## Safety considerations

DOMAQIN remains simulation-first and civilian. The project does not provide direct autonomous control of a physical aircraft, harmful payloads, target engagement, weapon systems, airspace restriction evasion, or unauthorized surveillance.
