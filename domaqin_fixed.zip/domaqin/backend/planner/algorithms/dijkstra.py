from __future__ import annotations
import heapq, math
from .base import GridPoint, PlanResult, NeighborFn, CostFn

def dijkstra(start: GridPoint, goal: GridPoint, neighbors: NeighborFn, cost: CostFn) -> PlanResult:
    frontier: list[tuple[float, int, GridPoint]] = [(0.0, 0, start)]
    came: dict[GridPoint, GridPoint] = {}
    best: dict[GridPoint, float] = {start: 0.0}
    visited = 0
    counter = 1
    while frontier:
        dist, _, current = heapq.heappop(frontier)
        visited += 1
        if dist != best.get(current):
            continue
        if current == goal:
            path = [current]
            while path[-1] != start:
                path.append(came[path[-1]])
            path.reverse()
            return PlanResult(path, visited, max(1, visited // 8), 0)
        for nxt in neighbors(current):
            nd = dist + cost(current, nxt)
            if nd < best.get(nxt, math.inf):
                best[nxt] = nd
                came[nxt] = current
                heapq.heappush(frontier, (nd, counter, nxt))
                counter += 1
    return PlanResult([], visited, 0, 0)
