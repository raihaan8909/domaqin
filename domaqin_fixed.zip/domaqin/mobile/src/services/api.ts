import { Algorithm, Mission, MissionType, Point, Telemetry } from '../models/types';

export const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8000';

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) }, ...init,
  });
  if (!response.ok) throw new Error((await response.text()) || `Request failed (${response.status})`);
  return response.json();
}

export const api = {
  listMissions: () => request<Mission[]>('/missions'),
  createMission: (payload: any) => request<Mission>('/missions', {method:'POST', body:JSON.stringify(payload)}),
  planMission: (id: number, algorithm?: Algorithm) => request<any>(`/missions/${id}/plan`, {method:'POST', body: JSON.stringify({algorithm})}),
  simulate: (id: number) => request<{mission:Mission; telemetry:Telemetry}>(`/missions/${id}/simulate`, {method:'POST'}),
  replan: (id: number, algorithm?: Algorithm) => request<any>(`/missions/${id}/replan`, {method:'POST', body: JSON.stringify({algorithm})}),
  event: (id: number, event_type: string, point?: Point) => request<any>(`/missions/${id}/events`, {method:'POST', body: JSON.stringify({event_type, point})}),
  parseAssistant: (text: string) => request<any>('/assistant/parse', {method:'POST', body: JSON.stringify({text})}),
  deleteMission: (id:number) => request<any>(`/missions/${id}`, {method:'DELETE'}),
};

export const toMissionPayload = (name:string, missionType:MissionType, description:string, start:Point, destination:Point, algorithm:Algorithm) => ({
  name, mission_type:missionType, description, start, destination, area:[], algorithm,
  constraints:{max_distance_km:8,max_flight_time_min:25,battery_reserve_pct:30,safety_margin_m:30,max_speed_mps:16,max_altitude_m:150},
  drone:{battery_capacity_mah:5200,starting_battery_pct:100,max_speed_mps:16,payload_weight_kg:.3,power_consumption_w:210}
});
