import React, { useMemo, useRef, useState } from 'react';
import { LayoutChangeEvent, Pressable, StyleSheet, Text, View, PanResponder } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../constants/theme';
import { Mission, Point } from '../models/types';

function lineStyle(a:Point,b:Point,w:number,h:number){
  const x1=a.x*w,y1=a.y*h,x2=b.x*w,y2=b.y*h; const dx=x2-x1,dy=y2-y1; const len=Math.max(1,Math.hypot(dx,dy));
  return {left:x1,top:y1,width:len,height:2,transform:[{rotate:`${Math.atan2(dy,dx)}rad`}] as any,};
}

export function MissionMap({mission,progress=0,obstacles=[],previousRoute,onTap,mode='view'}:{mission:Mission;progress?:number;obstacles?:Point[];previousRoute?:Point[];onTap?:(p:Point)=>void;mode?:'view'|'place'}){
 const [size,setSize]=useState({w:0,h:0}); const [scale,setScale]=useState(1); const [offset,setOffset]=useState({x:0,y:0}); const last=useRef({x:0,y:0});
 const responder=useMemo(()=>PanResponder.create({onStartShouldSetPanResponder:()=>true,onPanResponderGrant:(_,g)=>{last.current={x:g.x0,y:g.y0};},onPanResponderMove:(_,g)=>{setOffset({x:g.dx+last.current.x-g.x0,y:g.dy+last.current.y-g.y0});},onPanResponderRelease:()=>{}}),[]);
 const onLayout=(e:LayoutChangeEvent)=>setSize({w:e.nativeEvent.layout.width,h:e.nativeEvent.layout.height});
 const route=mission.route;
 const completedIndex=Math.floor((Math.max(0,Math.min(100,progress))/100)*Math.max(0,route.length-1));
 const handleTap=(e:any)=>{if(mode!=='place'||!onTap||!size.w)return; const x=Math.max(0,Math.min(1,(e.nativeEvent.locationX-offset.x)/(size.w*scale))); const y=Math.max(0,Math.min(1,(e.nativeEvent.locationY-offset.y)/(size.h*scale))); onTap({x,y});};
 return <View style={styles.wrap} onLayout={onLayout} {...(mode==='place'?{}:responder.panHandlers)}>
   <Pressable style={StyleSheet.absoluteFill} onPress={handleTap} accessibilityLabel={mode==='place'?'Simulation map; tap to place a point':'Interactive mission map'}>
     {size.w>0 && <View style={{position:'absolute',left:offset.x,top:offset.y,transform:[{scale}]}}>
       {Array.from({length:9}).map((_,i)=><View key={'cv'+i} style={[styles.contour,{left:i*size.w*.08,top:size.h*.12+(i%4)*size.h*.12,width:size.w*(.55-(i%3)*.06),height:size.h*.2, borderRadius:size.w, transform:[{rotate:`${-8+i*3}deg`}]}]}/>)}
       {route.slice(0,-1).map((p,i)=><View key={'r'+i} style={[lineStyle(p,route[i+1],size.w,size.h),styles.route,{backgroundColor:i<completedIndex?C.green:C.cyan}]}/>) }
       {previousRoute?.slice(0,-1).map((p,i)=><View key={'old'+i} style={[lineStyle(p,previousRoute[i+1],size.w,size.h),styles.oldRoute]}/>)}
       {obstacles.map((p,i)=><View key={'o'+i} style={[styles.obstacle,{left:p.x*size.w-11,top:p.y*size.h-11}]}><View style={styles.obstacleCore}/></View>)}
       <View style={[styles.pin,{left:mission.start.x*size.w-9,top:mission.start.y*size.h-9,backgroundColor:C.green}]}><Ionicons name="radio-outline" size={15} color={C.black}/></View>
       <View style={[styles.pin,{left:mission.destination.x*size.w-9,top:mission.destination.y*size.h-9,backgroundColor:C.red}]}><Ionicons name="flag" size={15} color={C.black}/></View>
       {route.map((p,i)=><View key={'wp'+i} style={[styles.waypoint,{left:p.x*size.w-4,top:p.y*size.h-4,backgroundColor:i<=completedIndex?C.green:C.cyan}]}/>) }
       {progress>0 && progress<100 && route.length>1 && (()=>{ const idx=Math.min(completedIndex,route.length-2); const local=(progress/100*(route.length-1))-idx; const a=route[idx],b=route[idx+1]; return <View style={[styles.drone,{left:(a.x+(b.x-a.x)*local)*size.w-12,top:(a.y+(b.y-a.y)*local)*size.h-12}]}><Ionicons name="navigate" size={20} color={C.text}/></View> })()}
     </View>}
   </Pressable>
   <View style={styles.badge}><View style={styles.dot}/><Text style={styles.badgeText}>SIMULATED TERRAIN • LOCAL GRID</Text></View>
   <View style={styles.zoom}><Pressable onPress={()=>setScale(Math.min(2,scale+.2))} style={styles.zoomBtn}><Text style={styles.zoomTxt}>+</Text></Pressable><Pressable onPress={()=>setScale(Math.max(.8,scale-.2))} style={styles.zoomBtn}><Text style={styles.zoomTxt}>−</Text></Pressable></View>
 </View>
}
const styles=StyleSheet.create({wrap:{height:320,borderRadius:20,overflow:'hidden',borderWidth:1,borderColor:C.line,backgroundColor:'#06101B'},contour:{position:'absolute',borderWidth:1,borderColor:'#1A5270',opacity:.34},route:{position:'absolute',borderRadius:2},oldRoute:{position:'absolute',borderRadius:2,backgroundColor:'#556273',opacity:.55},waypoint:{position:'absolute',width:8,height:8,borderRadius:8,borderWidth:2,borderColor:C.bg},pin:{position:'absolute',width:18,height:18,borderRadius:18,alignItems:'center',justifyContent:'center'},drone:{position:'absolute',width:24,height:24,borderRadius:24,backgroundColor:C.cyan,alignItems:'center',justifyContent:'center',borderWidth:2,borderColor:C.text},obstacle:{position:'absolute',width:22,height:22,borderRadius:22,borderWidth:2,borderColor:C.orange,alignItems:'center',justifyContent:'center'},obstacleCore:{width:7,height:7,borderRadius:7,backgroundColor:C.red},badge:{position:'absolute',left:10,top:10,flexDirection:'row',alignItems:'center',gap:6,paddingHorizontal:9,paddingVertical:6,borderRadius:10,backgroundColor:'rgba(2,5,11,.72)',borderWidth:1,borderColor:C.line},dot:{width:6,height:6,borderRadius:6,backgroundColor:C.cyan},badgeText:{color:C.muted,fontSize:9,fontWeight:'800',letterSpacing:.7},zoom:{position:'absolute',right:10,bottom:10,gap:6},zoomBtn:{width:34,height:34,borderRadius:10,borderWidth:1,borderColor:C.line,backgroundColor:'rgba(2,5,11,.75)',alignItems:'center',justifyContent:'center'},zoomTxt:{color:C.text,fontSize:20}});
