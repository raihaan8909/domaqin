import React from 'react';
import { ActivityIndicator, Pressable, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../constants/theme';
type ButtonProps = React.Attributes & {title:string;onPress?:()=>void;variant?:'primary'|'secondary'|'ghost'|'danger';icon?:keyof typeof Ionicons.glyphMap;loading?:boolean;disabled?:boolean;small?:boolean};
export function Button({title,onPress,variant='primary',icon,loading=false,disabled=false,small=false}:ButtonProps){
 const bg=variant==='primary'?C.cyan:variant==='danger'?C.red:'transparent'; const fg=variant==='primary'?C.black:C.text; const border=variant==='secondary'?C.line:variant==='ghost'?'transparent':bg;
 return <Pressable disabled={disabled||loading} onPress={onPress} style={({pressed})=>({minHeight:small?42:48,paddingHorizontal:small?12:16,borderRadius:14,backgroundColor:bg,borderWidth:1,borderColor:border,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:8,opacity:(disabled||loading)?0.45:pressed?.82:1})}>{loading?<ActivityIndicator color={fg}/>:<>{icon&&<Ionicons name={icon} size={small?16:18} color={fg}/>}<Text style={{color:fg,fontWeight:'800',fontSize:small?12:13,letterSpacing:.5}}>{title}</Text></>}</Pressable>
}
